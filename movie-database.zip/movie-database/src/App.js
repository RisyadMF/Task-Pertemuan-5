// Import Halaman Home
import Home from "./pages/home";

function App() {
  /**
   * Menampilkan Halaman Home.
   * Tag div bisa diganti dengan tag <>.
   * Tag <> adalah React fragment
   */
  return (
    <>
      <Home />
    </>
  );
}

export default App;
