import stayles from "./AddMoviesForm.module.css"


function AddMoviesForm() {
    return(
        <div className={stayles.container}>
            <section className={stayles.AddMoviesForm}>
                <div className={stayles.AddMoviesForm__right}>
                    <h2 className={stayles.AddMoviesForm__tittle}>Add Movie</h2>
                        <form className={stayles.AddMoviesForm__Form}>
                            <label className={stayles.AddMoviesForm__FormTittle} for="tittle">Tittle</label><br />
                            <input type="text" id="tittle" name="tittle" value="tittle" /><br />
                            <label className={stayles.AddMoviesForm__FormYear} for="year">Year</label><br />
                            <input type="text" id="year" name="year" value="year" /><br />
                            <input className={stayles.AddMoviesForm__formButton} type="submit" value="submit" />
                        </form>
                <div className={stayles.AddMoviesForm__left}>
                    <img className={stayles.AddMoviesForm__img} src="https:/picsum.photos/536/354" alt=""></img>
                </div>
                </div>
            </section>
        </div>

    ); 
}

export default AddMoviesForm;