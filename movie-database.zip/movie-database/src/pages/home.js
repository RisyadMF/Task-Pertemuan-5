// Import Navbar, Hero, Movies, Footer Component

import AddMoviesForm from "../component/AddMovies/AddMoviesForm";
import Footer from "../component/Footer/Footer";
import Hero from "../component/Hero/Hero";
import Movies from "../component/Movies/Movies";
import Navbar from "../component/Navbar/Navbar";



function Main() {
  return (
    <main>
      <Hero />
      <Movies />
      <AddMoviesForm />

    </main>
  );
}
function Home() {
  return (
    <>
      <Navbar />
      <Main />
      <Footer />
    </>
  );
}

export default Home;
